const mongoose=require("mongoose")

const productSchema=new mongoose.Schema({})
module.exports= mongoose.model("users",productSchema)