
import './App.css';
import Conditionfirst from './components/Conditionfirst';
import Conditionsecond from './components/Conditionsecond';
import Conditionthird from './components/Conditionthird';
import Conditionfour from './components/Conditionfour';
import Conditionfive from './components/Conditionfive';
import Nav from './components/Navitems';
import { BrowserRouter,Route,Routes } from 'react-router-dom';

function App() {

  return (
    <div>
      <BrowserRouter>
     <Nav/>
     <Routes>
     <Route path="/" element = {<Conditionfirst/>}/>
     <Route path="/conditionsecond" element={<Conditionsecond/>}/>
     <Route path="/conditionthird" element={<Conditionthird/>}/>
     <Route path="/conditionfour" element={<Conditionfour/>}/>
     <Route path="/conditionfive" element={<Conditionfive/>}/>
     </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
