import React from 'react'
import { useEffect,useState } from 'react';
import axios from 'axios';

const Conditionfirst = () => {
    
  const[products,setProducts]=useState([])
    useEffect(()=>{
        getProducts()
    },[])

    
const filteredUsers = products.filter(user => parseFloat(user.income.slice(1)) <= 5);
console.log(filteredUsers)

const getProducts=async()=>{
    let result = await axios.get("http://localhost:5000/")
     setProducts(result.data)
 }

  return (
    <div >

      <h1 class="hed">1. Users which have income lower than $5 USD and have a car of brand “BMW” or “Mercedes”</h1>
      <table>
       <tr>
        <th>S.No</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Income</th>
        <th>City</th>
        <th>Car</th>
        <th>Quote</th>
        <th>Phone Price</th>

    </tr>
      {
    filteredUsers.length>0?filteredUsers.map((item,index)=>{
      return(
      item.car==="BMW"||item.car==="Mercedes-Benz"?
        <tr key={item._id}>
        <td>{index+1}</td>
        <td>{item.first_name}</td>
        <td>{item.last_name}</td>
        <td>{item.email}</td>
        <td>{item.gender}</td>
        <td>{item.income}</td>
        <td>{item.city}</td>
        <td>{item.car}</td>
        <td>{item.quote}</td>
        <td>{item.phone_price}</td>
    </tr>:null
    )})
    :<h1>No Products Found</h1>
   }
   
   </table>

    </div>
  )
}

export default Conditionfirst