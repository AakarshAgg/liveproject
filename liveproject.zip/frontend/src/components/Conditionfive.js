import React from 'react'
import { useEffect,useState } from 'react';
import axios from 'axios';

const Conditionfive = () => {
    
  const[products,setProducts]=useState([])
    useEffect(()=>{
        getProducts()
    },[])


const cityData = {};

// iterate over each user object and group them by city
products.forEach(user => {
   if (!cityData[user.city]) {  //shows "true" because no city data is present initially,check for each new city
     cityData[user.city] = { count: 0, totalIncome: 0 };
   }
   cityData[user.city].count++;
   cityData[user.city].totalIncome += parseFloat(user.income.slice(1));

});


//create an array to store the city data in a sortable format

const sortableCityData = [];

for (const city in cityData) {
  const averageIncome = cityData[city].totalIncome / cityData[city].count;
  sortableCityData.push({ city, userCount: cityData[city].count, averageIncome });
}

let topCities=[]

// sort the array by user count in descending order and limit to top 10 cities
 topCities = sortableCityData.sort((a, b) => b.userCount - a.userCount).slice(0, 10);

const getProducts=async()=>{
  let result = await axios.get("http://localhost:5000/")
   setProducts(result.data)
}

  return (
    <div >

      <h1 class="hed">5. Show the data of top 10 cities which have the highest number of users and their average income.</h1>
    <table>
      <tr>
        <th>City</th>
        <th>User</th>
        <th>Average Income</th>
      </tr>
      {
         topCities.map((item,index)=>{
          return(
            <tr key={item._id}>
              <td>{item.city}</td>
              <td>{item.userCount}</td>
              <td>{item.averageIncome}</td>
            </tr>
          )
         })
      }
    </table>
     <table>
       <tr>
        <th>S.No</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Income</th>
        <th>City</th>
        <th>Car</th>
        <th>Quote</th>
        <th>Phone Price</th>

    </tr>
     {
    products.length>0?products.map((item,index)=>{
      return(
        topCities.map((element)=>{
          return(
      item.city===element.city?
        <tr key={item._id}>
        <td>{index+1}</td>
        <td>{item.first_name}</td>
        <td>{item.last_name}</td>
        <td>{item.email}</td>
        <td>{item.gender}</td>
        <td>{item.income}</td>
        <td>{item.city}</td>
        <td>{item.car}</td>
        <td>{item.quote}</td>
        <td>{item.phone_price}</td>
    </tr>:null)
}))})
    :<h1>No Products Found</h1>
   }
   
  </table>

    </div>
  )
}

export default Conditionfive