import React from 'react'
import { Link } from 'react-router-dom'

const Navitems = () => {
  return (
    <div>
        <nav>
            <ul>
                <li><Link to="/">Condition 1</Link></li>
                <li><Link to="/conditionsecond">Condition 2</Link></li>
                <li><Link to="/conditionthird">Condition 3</Link></li>
                <li><Link to="/conditionfour">Condition 4</Link></li>
                <li><Link to="/conditionfive">Condition 5</Link></li>
            </ul>
        </nav>
    </div>
  )
}

export default Navitems