import React from 'react'
import { useEffect,useState } from 'react';
import axios from 'axios';

const Conditionthird = () => {
    
  const[products,setProducts]=useState([])
    useEffect(()=>{
        getProducts()
    },[])


    const getProducts=async()=>{
      let result = await axios.get("http://localhost:5000/")
       setProducts(result.data)
   }

  return (
    <div >

      <h1 class="hed">3. Users whose last name starts with “M” and has a quote character length greater than 15 and email includes his/her last name.</h1>
      <table>
       <tr>
        <th>S.No</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Income</th>
        <th>City</th>
        <th>Car</th>
        <th>Quote</th>
        <th>Phone Price</th>

    </tr>
      {
    products.length>0?products.map((item,index)=>{
      return(
      item.last_name[0]==="M" && item.quote.length>15 && item.email.toLowerCase().includes(item.last_name.toLowerCase())?
        <tr key={item._id}>
        <td>{index+1}</td>
        <td>{item.first_name}</td>
        <td>{item.last_name}</td>
        <td>{item.email}</td>
        <td>{item.gender}</td>
        <td>{item.income}</td>
        <td>{item.city}</td>
        <td>{item.car}</td>
        <td>{item.quote}</td>
        <td>{item.phone_price}</td>
    </tr>:null
    )})
    :<h1>No Products Found</h1>
   }
   
   </table>

    </div>
  )
}

export default Conditionthird