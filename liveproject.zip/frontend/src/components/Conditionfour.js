import React from 'react'
import { useEffect,useState } from 'react';
import axios from 'axios';

const Conditionfour = () => {
    
  const[products,setProducts]=useState([])
    useEffect(()=>{
        getProducts()
    },[])

    const getProducts=async()=>{
      let result = await axios.get("http://localhost:5000/")
       setProducts(result.data)
   }

 const regex = /\d+/;

  return (
    <div >

      <h1 class="hed">4. Users which have a car of brand “BMW”, “Mercedes” or “Audi” and whose email does not include any digit.</h1>
      <table>
       <tr>
        <th>S.No</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Income</th>
        <th>City</th>
        <th>Car</th>
        <th>Quote</th>
        <th>Phone Price</th>

    </tr>
      {
    products.length>0?products.map((item,index)=>{
      return(
      ((item.car==="BMW"||item.car==="Mercedes-Benz" ||item.car==="Audi") && !regex.test(item.email))?
        <tr key={item._id}>
        <td>{index+1}</td>
        <td>{item.first_name}</td>
        <td>{item.last_name}</td>
        <td>{item.email}</td>
        <td>{item.gender}</td>
        <td>{item.income}</td>
        <td>{item.city}</td>
        <td>{item.car}</td>
        <td>{item.quote}</td>
        <td>{item.phone_price}</td>
    </tr>:null
    )})
    :<h1>No Products Found</h1>
   }
   
   </table>

    </div>
  )
}

export default Conditionfour